# accounts/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('request-otp-login/', views.request_otp_login, name='request_otp_login'),
    path('verify-otp-login/', views.verify_otp_login, name='verify_otp_login'),
]
