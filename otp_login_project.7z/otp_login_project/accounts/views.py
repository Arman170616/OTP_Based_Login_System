# accounts/views.py
from django.http import JsonResponse
from django.conf import settings
from twilio.rest import Client

def request_otp_login(request):
    phone_number = request.GET.get("phone_number")

    if phone_number:
        # Ensure phone number starts with '+'
        if not phone_number.startswith("+"):
            phone_number = f"+{phone_number}"

        client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
        try:
            verification = client.verify \
                .v2 \
                .services(settings.TWILIO_VERIFY_SERVICE_SID) \
                .verifications \
                .create(to=phone_number, channel='sms')
            return JsonResponse({"message": "OTP sent successfully", "sid": verification.sid})
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)
    return JsonResponse({"error": "Phone number is required"}, status=400)

def verify_otp_login(request):
    phone_number = request.GET.get("phone_number")
    otp_code = request.GET.get("otp_code")

    if phone_number and otp_code:
        # Ensure phone number starts with '+'
        if not phone_number.startswith("+"):
            phone_number = f"+{phone_number}"

        client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
        try:
            verification_check = client.verify \
                .v2 \
                .services(settings.TWILIO_VERIFY_SERVICE_SID) \
                .verification_checks \
                .create(to=phone_number, code=otp_code)

            if verification_check.status == "approved":
                # OTP is valid, proceed with login (e.g., create session)
                request.session['user_phone_number'] = phone_number
                return JsonResponse({"message": "Login successful"})
            else:
                return JsonResponse({"error": "Invalid OTP"}, status=400)
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)
    return JsonResponse({"error": "Phone number and OTP code are required"}, status=400)